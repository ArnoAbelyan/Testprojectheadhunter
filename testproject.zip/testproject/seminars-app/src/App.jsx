import { useEffect, useState } from "react";
import axios from "axios";
import { Button } from "./components/ui/Button";
import { Modal } from "./components/ui/Modal";
import { Input } from "./components/ui/Input";

const API_URL = "http://localhost:3001/seminars";

export default function SeminarsApp() {
  const [seminars, setSeminars] = useState([]);
  const [selectedSeminar, setSelectedSeminar] = useState(null);
  const [isEditModalOpen, setEditModalOpen] = useState(false);
  const [isDeleteModalOpen, setDeleteModalOpen] = useState(false);

  useEffect(() => {
    axios.get(API_URL).then((response) => setSeminars(response.data));
  }, []);

  const deleteSeminar = (id) => {
    axios.delete(`${API_URL}/${id}`).then(() => {
      setSeminars(seminars.filter((seminar) => seminar.id !== id));
      setDeleteModalOpen(false);
    });
  };

  const updateSeminar = () => {
    axios.put(`${API_URL}/${selectedSeminar.id}`, selectedSeminar).then(() => {
      setSeminars(
        seminars.map((seminar) =>
          seminar.id === selectedSeminar.id ? selectedSeminar : seminar
        )
      );
      setEditModalOpen(false);
    });
  };

  return (
    <div className="p-4">
      <h1 className="text-xl font-bold">Семинары</h1>
      <ul>
        {seminars.map((seminar) => (
          <li key={seminar.id} className="flex justify-between p-2 border">
            {seminar.title}
            <div>
              <Button onClick={() => { setSelectedSeminar(seminar); setEditModalOpen(true); }}>Редактировать</Button>
              <Button onClick={() => { setSelectedSeminar(seminar); setDeleteModalOpen(true); }}>Удалить</Button>
            </div>
          </li>
        ))}
      </ul>

      {/* Модальное окно для редактирования */}
      {isEditModalOpen && (
        <Modal onClose={() => setEditModalOpen(false)}>
          <h2>Редактировать семинар</h2>
          <Input
            value={selectedSeminar.title}
            onChange={(e) => setSelectedSeminar({ ...selectedSeminar, title: e.target.value })}
          />
          <Button onClick={updateSeminar}>Сохранить</Button>
        </Modal>
      )}

      {/* Модальное окно для удаления */}
      {isDeleteModalOpen && (
        <Modal onClose={() => setDeleteModalOpen(false)}>
          <h2>Удалить семинар?</h2>
          <Button onClick={() => deleteSeminar(selectedSeminar.id)}>Удалить</Button>
        </Modal>
      )}
    </div>
  );
}
