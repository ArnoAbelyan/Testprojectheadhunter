export function Input({ value, onChange }) {
    return <input className="border p-2 w-full" value={value} onChange={onChange} />;
  }
  